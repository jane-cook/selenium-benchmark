/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package benchmark;

import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import seleniumrobots.engine.driver.DriverTypes;
import seleniumrobots.engine.driver.WebDriverFactory;
import seleniumrobots.engine.task.TaskParams;
import seleniumrobots.engine.task.Template;
import seleniumrobots.engine.task.TemplateResult;
import upiter.files.FileManager;

/**
 *
 * @author Happy
 */
public class Benchmark implements Template {
    
    String projectPath;
    Object syncObj = new Object();
    
    int waitTime = 5;
    int waitIter = 0;
    int waitMax = 1200;
    
    String binary = FileManager.read("browser_binary.txt").trim();

    public static CopyOnWriteArrayList<Double> results = new CopyOnWriteArrayList<Double>();

    @Override
    public TemplateResult doTask(TaskParams taskParams, boolean silent) throws Exception {
        
        WebDriver driver = null;
        
        try {
            
            DriverTypes driverType = DriverTypes.CHROME;
            
            if (taskParams.otherParams.length > 0) {
                try {
                    driverType = DriverTypes.valueOf(((String)taskParams.otherParams[0]).toUpperCase());
                } catch (Exception e) {
                }
            }
            
            driver = WebDriverFactory.getWebDriver(driverType, binary);
            
            Thread.sleep(10000);
            
            ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
            driver.switchTo().window(tabs.get(0));
            
            String score = "";

            driver.get("http://browserbench.org/JetStream/");
            
            Thread.sleep(2000);
            
            ((JavascriptExecutor) driver).executeScript("void(JetStream.start());");
            
            Thread.sleep(waitTime * 2 * 1000);
            
            WebElement element = null;
            boolean elementFound = false;
            
            try {
                element = driver.findElement(By.xpath("//em[contains(text(),'Running iteration')]"));
                if (element != null)
                    elementFound = true;
            } catch (Exception e) {
            }
            
            if (elementFound) {
                while (waitIter < waitMax) {
                    element = null;
                    
                    try {
                        element = driver.findElement(By.xpath("//div[@id='result-summary']/span[@class='score']"));
                    } catch (Exception e) {
                    }
                    
                    if ((element != null) && element.isDisplayed()) {
                        
                        Matcher m = Pattern.compile("[\\d]+\\.[\\d]+").matcher(element.getText());
                        m.find();
                        try {
                            score = m.group();
                        } catch (Exception e) {
                            System.out.println("JetStream не смог подсчитать результат!");
                            return new TemplateResult(false, false);
                        }
                        results.add(Double.parseDouble(score));
                        return new TemplateResult(true, false);
                    }
                    
                    Thread.sleep(waitTime * 1000);
                    
                    waitIter += waitTime;
                    
                }
                
                if (waitIter >= waitMax) {
                    System.out.println("Не удалось дождаться результата!");
                    return new TemplateResult(false, false);
                }
            } else {
                System.out.println("Не смогли запустить тестирование!");
                return new TemplateResult(false, false);
            }
            
            return new TemplateResult(false, false);
        } catch (Exception ex) {
            System.out.println("----------------------------------------------------------------------------");
            System.out.println("Что-то пошло не так: ");
            Logger.getLogger(Benchmark.class.getName()).log(Level.SEVERE, null, ex);
            return new TemplateResult(false, false);        
        } finally {
            if (driver != null)
                driver.quit();
        }
    }
    
    
}
