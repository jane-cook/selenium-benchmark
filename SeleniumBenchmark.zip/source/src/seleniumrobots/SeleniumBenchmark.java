/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package seleniumrobots;

import benchmark.Benchmark;
import java.io.IOException;
import seleniumrobots.engine.task.TemplateResult;
import seleniumrobots.engine.task.TaskParams;
import seleniumrobots.engine.task.Template;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.text.DecimalFormat;
import java.util.Collections;
import java.util.OptionalDouble;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;
import upiter.files.FileManager;

/**
 *
 * @author Happy
 */
public class SeleniumBenchmark {

    /**
     * @param args the command line arguments
     */
    
    static AtomicInteger i = new AtomicInteger(0);
    static Object syncObject = new Object();
    static int threadsNum = 1;
    static int tasksNum = 1;
    static boolean silent = true;
    static String driverType = "chrome";
    
    public static void main(String[] args) throws InterruptedException, UnsupportedEncodingException, InstantiationException, IllegalAccessException, NoSuchMethodException, IllegalArgumentException, InvocationTargetException, IOException {

        class SeleniumRobotsThread implements Runnable {

            Template template;
            TaskParams tp;

            public SeleniumRobotsThread(Template template, TaskParams tp) {

                this.template = template;
                this.tp = tp;
            }

            @Override
            public void run() {
                while (i.get() < tasksNum) {

                    synchronized (syncObject) {
                            i.getAndIncrement();
                    }
                    
                    TemplateResult templateResult = new TemplateResult();

                    try {
                        templateResult = template.doTask(tp, silent);
                    } catch (Exception e) {
                        Logger.getLogger(SeleniumBenchmark.class.getName()).log(Level.SEVERE, null, e);
                    }

                    if (!templateResult.result) {
                        if (templateResult.canContinue) {
                            synchronized (syncObject) {
                                i.decrementAndGet();
                            }
                        } else if (!templateResult.canContinue) {
                            while(true);
                        }
                    }

                }
                
                synchronized (syncObject) {
                    if (Benchmark.results.size() >= threadsNum) {

                        String s = "";
                        String sResults = "";
                        for (double res: Benchmark.results)
                            sResults += res + "\r\n";
                        
                        s += "Результат по " + threadsNum + " параллельным потокам (по числу ядер в системе):\r\n";
                        
                        double scoresAverage = ((OptionalDouble)Benchmark.results
                                                    .stream()
                                                    .mapToDouble(a -> a)
                                                    .average()).getAsDouble();
                        
                        double scoresMin = Collections.min(Benchmark.results);
                        double scoresMax = Collections.max(Benchmark.results);
                        double scoresAverageOnPercent = scoresAverage / 100;
                        int maxDiffPercent = 15;
                        double diffPercent = scoresAverageOnPercent * maxDiffPercent;
                        
                        DecimalFormat df = new DecimalFormat("0.00");  
                         
                        if ((Math.abs(scoresAverage - scoresMin) > diffPercent) ||
                                (Math.abs(scoresMax - scoresAverage) > diffPercent)){
                            s += "Максимальный процент разницы ("
                                    + maxDiffPercent + "%) - превышен! Запустите тестирование заново!\r\n";
                            
                            s += "Среднее: " + df.format(scoresAverage)
                                    + " / Максимум: " + df.format(scoresMax) + " / Минимум: "
                                    + df.format(scoresMin) + "\r\n";
                        } else {
                            s += "Сумма результатов: " + df.format(Benchmark.results.stream().mapToDouble(a -> a).sum()) + "\r\n";
                        }
                        
                        System.out.print(s);
                        FileManager.save("result_" + driverType + ".txt", sResults + s);
                        
                        while(true);
                    }
                }
            }

        }

        //args = new String[]{"chrome"};

        threadsNum = Runtime.getRuntime().availableProcessors();
        tasksNum = Runtime.getRuntime().availableProcessors();
        driverType = args[0];
        silent = false;
        
        Template template = null;
        TaskParams tp = new TaskParams(args);

        for (int j = 0; j < threadsNum; j++) {

            Template workingTemplate = new Benchmark();
            SeleniumRobotsThread srt = new SeleniumRobotsThread(workingTemplate, tp);
            Thread tr = new Thread(srt);
            tr.start();
          //  Thread.sleep(10000);
        
        }
        
        System.out.println("----------------------------------------------------------------------------");
        System.out.println("Запустили " + threadsNum + " параллельных потоков (по числу ядер в системе)");
            

    }

}
