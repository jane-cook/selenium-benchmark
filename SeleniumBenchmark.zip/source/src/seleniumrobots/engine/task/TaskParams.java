/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seleniumrobots.engine.task;

/**
 *
 * @author Happy
 */
public class TaskParams{
        public String proxy;
        public String userAgent;
        public String screenSize;
        public String windowSize;
        public String pixelRatio;
        public String device;
        public String profileName;
        public boolean mobile = false;
        public Object[] otherParams;
        
        public UserData userData;

        
        private TaskParams(String proxy, String profileName, boolean mobile, UserData ud) {
            this.proxy = proxy;
            this.profileName = profileName;
            this.mobile = mobile;
            this.userData = ud;
        }
        
        public TaskParams(String proxy, String profileName, boolean mobile, String userAgent, String screenSize, String windowSize, String pixelRatio, UserData ud) {
            this(proxy, profileName, mobile, ud);
            this.userAgent = userAgent;
            this.screenSize = screenSize;
            this.windowSize = windowSize;
            this.pixelRatio = pixelRatio;
        }
        
        public TaskParams(String proxy, String profileName, String device, UserData ud) {
            this(proxy, profileName, true, ud);
            this.device = device;
        }

        public TaskParams(String proxy, String profileName, boolean mobile, String userAgent, String screenSize, String windowSize, String pixelRatio, UserData ud, Object[] otherParams) {
            this(proxy, profileName, mobile, userAgent, screenSize, windowSize, pixelRatio, ud);
            this.otherParams = otherParams;
        }
        
        public TaskParams(String proxy, String profileName, String device, UserData ud, Object[] otherParams) {
            this(proxy, profileName, device, ud);
            this.otherParams = otherParams;
        }
        
        public TaskParams(Object[] otherParams) {
            this.otherParams = otherParams;
        }
    }