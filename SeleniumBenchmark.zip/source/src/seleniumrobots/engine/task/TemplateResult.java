/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seleniumrobots.engine.task;

/**
 *
 * @author Happy
 */
public class TemplateResult {
    public boolean result = false;
    public boolean canContinue = true;

    public TemplateResult(boolean result, boolean canContinue) {
        this.result = result;
        this.canContinue = canContinue;
    }
    
    public TemplateResult() {
        this.result = false;
        this.canContinue = true;
    }

}
