/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seleniumrobots.engine.task;

import java.util.ArrayList;
import org.openqa.selenium.WebDriver;
import seleniumrobots.engine.task.TaskParams;

/**
 *
 * @author Happy
 */
public interface Template {
    public TemplateResult doTask(TaskParams taskParams, boolean silent) throws Exception;
}
