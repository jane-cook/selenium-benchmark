/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seleniumrobots.engine.task;

/**
 *
 * @author Happy
 */
public class UserData {
    public String name;
    public String surname;
    public String login;
    public String password;
    public String email;
    public String profileUrlPart;
    public int birthDay;
    public int birthMonth;
    public int birthYear;
    public String phone;

    public UserData(String name, String surname, String login, String password, String email, String profileUrlPart, int birthDay, int birthMonth, int birthYear, String phone) {
        this.name = name;
        this.surname = surname;
        this.login = login;
        this.password = password;
        this.email = email;
        this.profileUrlPart = profileUrlPart;
        this.birthDay = birthDay;
        this.birthMonth = birthMonth;
        this.birthYear = birthYear;
        this.phone = phone;
    }

    public UserData() {
    }

    @Override
    public String toString() {
        return name + " " + surname + "|" + password + "|"
                + email + "|" + profileUrlPart + "|"
                + birthDay + " " + birthMonth
                + " " + birthYear + "|" + phone;
    }
    
}
