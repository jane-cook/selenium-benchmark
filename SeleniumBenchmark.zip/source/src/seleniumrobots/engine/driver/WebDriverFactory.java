/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seleniumrobots.engine.driver;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import seleniumrobots.engine.task.TaskParams;

/**
 *
 * @author Happy
 */
public class WebDriverFactory {

    
    public static String binary = "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe";
                                  /*"C:\\Users\\Happy\\AppData\\Local\\Epic Privacy Browser\\Application\\epic.exe"*/
                                  /*"W:\\progs\\SRWare Iron\\chrome.exe"*/
                                  /*"W:\progs\Vivaldi\Application\vivaldi.exe"*/
    
    
    public static WebDriver getWebDriver(DriverTypes driverType, String binaryPath) {
        

        WebDriver driver = null;
        
        Map<String, Object> options = new HashMap<String, Object>();
        DesiredCapabilities capabilities;
        
        switch (driverType) {

            case CHROME:

                System.setProperty("webdriver.chrome.driver", "browser_drivers\\chromedriver.exe");

                options.put("binary", binaryPath);

                capabilities = DesiredCapabilities.chrome();

                capabilities.setCapability(ChromeOptions.CAPABILITY, options);
                capabilities.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);

                driver = new ChromeDriver(capabilities);
                break;
                
            case FIREFOX:
                System.setProperty("webdriver.gecko.driver", "browser_drivers\\geckodriver.exe");

                capabilities = DesiredCapabilities.firefox();

                options.put("binary", binaryPath);
                
                capabilities.setCapability(FirefoxOptions.FIREFOX_OPTIONS, options);
                capabilities.setCapability("marionette", true);

                driver = new FirefoxDriver(capabilities);
                break;
                
            case IE:
                System.setProperty("webdriver.ie.driver", "browser_drivers\\IEDriverServer.exe");

                capabilities = DesiredCapabilities.internetExplorer();
                
                capabilities.setCapability("ie.binary", binaryPath);

                driver = new InternetExplorerDriver(capabilities);
                break;
                
        }

        return driver;
    }
}
