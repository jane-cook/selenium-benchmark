/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seleniumrobots.engine;

import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Happy
 */
public class Basic {
    
    private static Random r = new Random();
    
    private static CopyOnWriteArrayList<String> filesInUse = new CopyOnWriteArrayList<String>();
    
    public static void randomPause(int from, int to) {
        try {
            Thread.sleep(from + r.nextInt(to - from));
        } catch (InterruptedException ex) {
            Logger.getLogger(Basic.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static String getRandomFilePath(String pathToFolder) {
        File folder = new File(pathToFolder);
        File[] listOfFiles = folder.listFiles();

        File file = listOfFiles[r.nextInt(listOfFiles.length)];
        return file.getAbsolutePath();
    }
    
    public static synchronized String getRandomFilePathSafe(String pathToFolder) {
        
        String filepath = "";
        
        for (int i = 0; i < 10; i++){
            File folder = new File(pathToFolder);
            File[] listOfFiles = folder.listFiles();

            File file = listOfFiles[r.nextInt(listOfFiles.length)];

            filepath = file.getAbsolutePath();
            
            if (!filesInUse.contains(filepath))
                break;
            
            try {
                Thread.sleep(10000);
            } catch (InterruptedException ex) {
                Logger.getLogger(Basic.class.getName()).log(Level.SEVERE, null, ex);
            }
        } 
        
        filesInUse.add(filepath);
        
        return filepath;
    }
    
    public static synchronized void releaseRandomFilePathSafe (String filepath){
        try {
            filesInUse.remove(filepath);
        } catch (Exception e) {
        }
    }
    
    public static ResultSet dbExecuteQuery(Connection connection, String sql) throws SQLException{
        connection.setAutoCommit(false);
        Statement st = connection.createStatement();
        ResultSet rs = st.executeQuery(sql);
        connection.commit();
        
        return rs;
    }
    
    public static int dbExecuteUpdate(Connection connection, String sql) throws SQLException{
        connection.setAutoCommit(false);
        Statement st = connection.createStatement();
        int rs = st.executeUpdate(sql);
        connection.commit();
        
        return rs;
    }
}
